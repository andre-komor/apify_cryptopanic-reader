# CryptoPanic News Grabber – privater Apify Actor v0.2

Dieser Actor lädt den öffentlichen CryptoPanic-Newsfeed in Chromium und liest die von CryptoPanic im Browser entschlüsselten strukturierten News-Payloads aus. Für den öffentlichen Feed werden weder CryptoPanic-Login noch gespeicherte Sitzung benötigt.

## Warum v0.2?

Die erste Version verwendete `PlaywrightCrawler` und schrieb den ersten eigenen Logeintrag relativ spät. v0.2 verwendet Playwright direkt und protokolliert jeden Startschritt. Dadurch ist sofort sichtbar, ob das Problem beim Actor-Start, beim Browser-Start, bei der Navigation, am CryptoPanic-Endpunkt oder beim Payload-Hook liegt.

Bei einem Fehler legt der Actor automatisch folgende Records im Default Key-Value Store ab:

- `ERROR_SCREENSHOT`
- `ERROR_PAGE`
- `ERROR_DIAGNOSTICS`

Bei `debug: true` werden zusätzlich `DEBUG_SCREENSHOT`, `DEBUG_PAGE` und `DEBUG_DIAGNOSTICS` gespeichert.

## Ergebnisfelder

- `aiSentimentLevel`
- `body`
- `coins` – beim Apify-XLSX-Export entstehen `coins/0`, `coins/1`, `coins/2`, …
- `contentClean`
- `createdAt`
- `headline`
- `kind`
- `panicScore`
- `panicScore1h`
- `panicScore24h`
- `publishedAt`
- `source`
- `sourceRegion`
- `sourceTitle`
- `sourceUrl`

Fehlende Werte bleiben `null`.

# Lokale Entwicklung unter Debian/Parrot + VSCodium

## 1. Projekt entpacken

Empfohlener Pfad:

```bash
mkdir -p /home/user/GIT/DEV
cd /home/user/GIT/DEV
unzip cryptopanic-news-grabber-apify-v0.2.zip
cd cryptopanic-news-grabber-apify-v0.2
```

## 2. Node.js 24 bereitstellen

Das lokale Node sollte zur Cloud-Dockerbasis passen:

```bash
node --version
```

Sollte nicht `v24.x` erscheinen, beispielsweise mit `fnm`:

```bash
curl -fsSL https://fnm.vercel.app/install | bash
exec "$SHELL"
fnm install 24
fnm use 24
node --version
```

Die Datei `.nvmrc` enthält ebenfalls `24`.

## 3. Apify CLI installieren

```bash
npm install -g apify-cli
apify --version
```

Alternativ kann die eigenständige Linux-Installation verwendet werden:

```bash
curl -fsSL https://apify.com/install-cli.sh | bash
```

Für lokale Runs ist kein Login erforderlich. Login wird erst für `apify push` benötigt.

## 4. Abhängigkeiten und Chromium installieren

```bash
npm ci
npx playwright install --with-deps chromium
```

`--with-deps` benötigt auf Debian/Parrot gegebenenfalls `sudo` für Systempakete.

## 5. Tests ausführen

```bash
npm run test:all
npm run check
```

Die normalen Tests prüfen Feld-Mapping und Deduplizierung. Der Browser-Test verwendet ausschließlich eine lokale Fixture und erzeugt keinen bezahlten Apify-Run.

## 6. Actor lokal starten

Headless:

```bash
APIFY_LOG_LEVEL=DEBUG apify run --input-file INPUT.local.json -p
```

Oder:

```bash
npm run dev
```

Mit sichtbarem Chromium-Fenster:

```bash
npm run dev:headful
```

Lokale Ergebnisse liegen anschließend unter:

```text
storage/datasets/default/
storage/key_value_stores/default/OUTPUT.json
storage/key_value_stores/default/DEBUG_DIAGNOSTICS.json
storage/key_value_stores/default/DEBUG_SCREENSHOT.png
```

`-p` leert den lokalen Default-Storage vor dem Run.

# VSCodium

Projektordner öffnen:

```bash
codium /home/user/GIT/DEV/cryptopanic-news-grabber-apify-v0.2
```

Unter **Terminal → Run Task** stehen bereit:

- `Actor: install`
- `Actor: test all`
- `Actor: run local headless`
- `Actor: run local headful`
- `Actor: validate`
- `Actor: deploy`

Unter **Run and Debug** steht `Debug Actor main.js` bereit. Damit können Breakpoints direkt in `src/main.js`, `src/scrape.js` und `src/cryptopanic.js` gesetzt werden.

Das enthaltene `AGENTS.md` gibt Codex den Projektvertrag vor: keine bezahlten Cloud-Runs in Tests, keine erfundenen Scores, feste Ausgabefelder und lokale Fixtures.

# Docker-Test mit weitgehend gleicher Laufzeit wie Apify Cloud

Docker ist für den normalen Entwicklungszyklus nicht zwingend, aber sinnvoll vor dem Deployment:

```bash
npm run prepare:input
docker compose build
docker compose run --rm actor
```

Die Dockerbasis ist dieselbe Apify-Node/Playwright-Variante, die später in der Cloud verwendet wird.

# Deployment in den bestehenden Actor

Zuerst anmelden:

```bash
apify login
```

Dann mit der Actor-ID aus der Console-URL deployen:

```bash
apify push <ACTOR_ID> --open
```

Anschließend in Apify einen Test-Run mit 1024 MB starten und temporär diese Environment Variable setzen:

```text
APIFY_LOG_LEVEL=DEBUG
```

Erwartete erste Logzeilen:

```text
[BOOT] CryptoPanic Actor module loaded ...
INFO System info ...
INFO Actor main function entered ...
INFO Input loaded ...
INFO Launching Chromium ...
INFO Capture hook installed; starting navigation ...
```

Erscheinen weiterhin ausschließlich die von `ACTOR:` eingeleiteten Plattformzeilen, läuft nicht die neue `src/main.js` oder der Anwendungs-Loglevel ist unterhalb `INFO` gesetzt.

# Empfohlener Cloud-Testinput

```json
{
  "filter": "all",
  "maxItems": 50,
  "maxLoadMoreClicks": 3,
  "maxAgeHours": 0,
  "onlyNew": false,
  "headless": true,
  "navigationTimeoutSecs": 45,
  "payloadTimeoutSecs": 30,
  "proxyConfiguration": {
    "useApifyProxy": false
  },
  "debug": true
}
```

Erst wenn `ERROR_DIAGNOSTICS` oder das Screenshot eine Sperre zeigt, einen Apify-Datacenter-Proxy testen.

# Hinweise zur vorhandenen Web-IDE-Version

Wenn ein ZIP in ein bereits aus einem Template erzeugtes Web-IDE-Projekt importiert wird, können alte Dateien wie `src/routes.js`, `.github/`, `CLAUDE.md` oder Template-Tests zurückbleiben. Sie müssen nicht zwingend den Build brechen, machen aber unklar, welche Quelle tatsächlich ausgeführt wird. Ein sauberer lokaler Projektordner plus `apify push <ACTOR_ID>` vermeidet dieses Mischen.
