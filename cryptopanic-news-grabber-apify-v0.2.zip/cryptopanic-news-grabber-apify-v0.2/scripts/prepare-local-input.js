import { copyFile, mkdir, rm } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const storage = resolve(root, 'storage');
const targetDir = resolve(storage, 'key_value_stores', 'default');

await rm(storage, { recursive: true, force: true });
await mkdir(targetDir, { recursive: true });
await copyFile(resolve(root, 'INPUT.local.json'), resolve(targetDir, 'INPUT.json'));
console.log(`Prepared local Actor input at ${resolve(targetDir, 'INPUT.json')}`);
