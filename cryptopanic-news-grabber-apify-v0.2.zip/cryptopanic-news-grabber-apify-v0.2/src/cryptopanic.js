import { createHash } from 'node:crypto';

const FILTER_ALIASES = Object.freeze({
    'show-all': 'all',
    'top-saved': 'saved',
});

export function buildFeedUrl({ filter = 'all', startUrl = '' } = {}) {
    if (startUrl?.trim()) {
        const parsed = new URL(startUrl.trim());
        if (!['http:', 'https:'].includes(parsed.protocol)) {
            throw new Error('startUrl must use http or https');
        }
        return parsed.toString();
    }

    const normalizedFilter = FILTER_ALIASES[filter] ?? filter ?? 'all';
    const url = new URL('https://cryptopanic.com/news/');
    url.searchParams.set('filter', normalizedFilter);
    return url.toString();
}

export function expandDictList(payload) {
    if (!payload || !Array.isArray(payload.k) || !Array.isArray(payload.l)) return [];

    const keys = payload.k;
    return payload.l.flatMap((row) => {
        if (!Array.isArray(row) || row.length !== keys.length) return [];
        return [Object.fromEntries(keys.map((key, index) => [key, row[index]]))];
    });
}

function firstDefined(...values) {
    return values.find((value) => value !== undefined && value !== null) ?? null;
}

function toIsoOrNull(value) {
    if (!value) return null;
    const date = value instanceof Date ? value : new Date(value);
    return Number.isNaN(date.getTime()) ? String(value) : date.toISOString();
}

function normalizeCoins(post) {
    const raw = firstDefined(post.currencies_codes, post.coins, post.instruments, post.currencies);
    if (!Array.isArray(raw)) return [];

    const result = raw
        .map((entry) => {
            if (typeof entry === 'string') return entry;
            if (entry && typeof entry === 'object') return firstDefined(entry.code, entry.symbol, entry.ticker);
            return null;
        })
        .filter((entry) => typeof entry === 'string' && entry.trim())
        .map((entry) => entry.trim().toUpperCase());

    return [...new Set(result)];
}

function normalizeContent(post) {
    const content = post.content;
    if (content && typeof content === 'object' && !Array.isArray(content)) {
        return {
            clean: firstDefined(content.clean, content.text, content.content_clean),
            html: firstDefined(content.original, content.html, content.raw),
        };
    }

    return {
        clean: firstDefined(post.content_clean, post.contentClean),
        html: firstDefined(post.content_html, post.contentHtml, typeof content === 'string' ? content : null),
    };
}

export function postIdentity(post) {
    const source = firstDefined(
        post.pk,
        post.id,
        post.remote_id,
        post.remoteId,
        post.url,
        post.original_url,
        `${post.title ?? ''}|${post.published_at ?? ''}`,
    );
    return createHash('sha256').update(String(source)).digest('hex');
}

export function normalizePost(post) {
    const sourceObject = post.source && typeof post.source === 'object' ? post.source : {};
    const content = normalizeContent(post);

    return {
        aiSentimentLevel: firstDefined(post.ai_sentiment_level, post.aiSentimentLevel),
        body: firstDefined(post.body, post.description),
        coins: normalizeCoins(post),
        contentClean: content.clean,
        createdAt: toIsoOrNull(firstDefined(post.created_at, post.createdAt)),
        headline: firstDefined(post.title, post.headline),
        kind: firstDefined(post.kind, sourceObject.type),
        panicScore: firstDefined(post.panic_score, post.panicScore),
        panicScore1h: firstDefined(post.panic_score_1h, post.panicScore1h),
        panicScore24h: firstDefined(post.panic_score_24h, post.panicScore24h),
        publishedAt: toIsoOrNull(firstDefined(post.published_at, post.publishedAt)),
        source: firstDefined(sourceObject.domain, post.domain),
        sourceRegion: firstDefined(sourceObject.region, post.region),
        sourceTitle: firstDefined(sourceObject.title, post.source_title, typeof post.source === 'string' ? post.source : null),
        sourceUrl: firstDefined(post.original_url, post.source_url, post.url),
    };
}

export function normalizeAndDeduplicate(rawPosts, { maxItems = 150, maxAgeHours = 0 } = {}) {
    const cutoff = maxAgeHours > 0 ? Date.now() - maxAgeHours * 60 * 60 * 1000 : null;
    const unique = new Map();

    for (const post of rawPosts) {
        if (!post || typeof post !== 'object' || post.kind === 'sponsored') continue;

        const item = normalizePost(post);
        if (!item.headline || !item.publishedAt) continue;

        if (cutoff !== null) {
            const published = new Date(item.publishedAt).getTime();
            if (!Number.isNaN(published) && published < cutoff) continue;
        }

        const id = postIdentity(post);
        if (!unique.has(id)) unique.set(id, { id, item });
    }

    return [...unique.values()]
        .sort((a, b) => new Date(b.item.publishedAt).getTime() - new Date(a.item.publishedAt).getTime())
        .slice(0, maxItems);
}

export function makeStateKey(feedUrl) {
    return `SEEN_${createHash('sha256').update(feedUrl).digest('hex').slice(0, 20).toUpperCase()}`;
}
