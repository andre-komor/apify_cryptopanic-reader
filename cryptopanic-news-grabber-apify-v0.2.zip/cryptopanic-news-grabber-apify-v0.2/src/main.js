import process from 'node:process';

import { Actor, log } from 'apify';
import { chromium } from 'playwright';

import {
    buildFeedUrl,
    makeStateKey,
    normalizeAndDeduplicate,
} from './cryptopanic.js';
import { scrapeCryptoPanicFeed } from './scrape.js';

console.log(`[BOOT] CryptoPanic Actor module loaded at ${new Date().toISOString()} (Node ${process.version})`);
process.on('uncaughtExceptionMonitor', (error) => {
    console.error('[FATAL] uncaught exception', error);
});
process.on('unhandledRejection', (reason) => {
    console.error('[FATAL] unhandled rejection', reason);
});

function integer(value, fallback, { min = 0, max = Number.MAX_SAFE_INTEGER } = {}) {
    const parsed = Number(value);
    if (!Number.isInteger(parsed)) return fallback;
    return Math.min(max, Math.max(min, parsed));
}

async function makePlaywrightProxy(proxyInput) {
    const options = proxyInput && typeof proxyInput === 'object'
        ? { ...proxyInput, checkAccess: false }
        : { useApifyProxy: false, checkAccess: false };

    const configuration = await Actor.createProxyConfiguration(options);
    if (!configuration) return undefined;

    const rawUrl = await configuration.newUrl(`cryptopanic-${Date.now()}`);
    if (!rawUrl) return undefined;

    const parsed = new URL(rawUrl);
    const proxy = { server: `${parsed.protocol}//${parsed.host}` };
    if (parsed.username) proxy.username = decodeURIComponent(parsed.username);
    if (parsed.password) proxy.password = decodeURIComponent(parsed.password);
    return proxy;
}

async function saveArtifacts(prefix, page, diagnostics) {
    try {
        const screenshot = await page.screenshot({ fullPage: true });
        await Actor.setValue(`${prefix}_SCREENSHOT`, screenshot, { contentType: 'image/png' });
    } catch (error) {
        log.warning('Could not save browser screenshot', { prefix, error: error.message });
    }

    try {
        await Actor.setValue(`${prefix}_PAGE`, await page.content(), {
            contentType: 'text/html; charset=utf-8',
        });
    } catch (error) {
        log.warning('Could not save browser HTML', { prefix, error: error.message });
    }

    await Actor.setValue(`${prefix}_DIAGNOSTICS`, diagnostics);
}

await Actor.main(async () => {
    log.info('Actor main function entered', {
        isAtHome: Actor.isAtHome(),
        nodeVersion: process.version,
        logLevel: process.env.APIFY_LOG_LEVEL ?? 'INFO (default)',
        executablePathOverride: Boolean(process.env.PLAYWRIGHT_EXECUTABLE_PATH),
    });

    const input = (await Actor.getInput()) ?? {};
    const filter = String(input.filter ?? 'all');
    const maxItems = integer(input.maxItems, 150, { min: 1, max: 1_000 });
    const maxLoadMoreClicks = integer(input.maxLoadMoreClicks, 12, { min: 0, max: 100 });
    const maxAgeHours = integer(input.maxAgeHours, 0, { min: 0, max: 8_760 });
    const navigationTimeoutSecs = integer(input.navigationTimeoutSecs, 60, { min: 15, max: 180 });
    const payloadTimeoutSecs = integer(input.payloadTimeoutSecs, 30, { min: 5, max: 120 });
    const slowMoMillis = integer(input.slowMoMillis, 0, { min: 0, max: 2_000 });
    const onlyNew = Boolean(input.onlyNew ?? false);
    const stateStoreName = String(input.stateStoreName ?? 'cryptopanic-news-grabber-state');
    const datasetName = String(input.datasetName ?? '');
    const startUrl = String(input.startUrl ?? '');
    const headless = input.headless !== false;
    const debug = Boolean(input.debug ?? false);
    const proxyInput = input.proxyConfiguration ?? { useApifyProxy: false };
    const feedUrl = buildFeedUrl({ filter, startUrl });

    log.info('Input loaded', {
        feedUrl,
        maxItems,
        maxLoadMoreClicks,
        maxAgeHours,
        navigationTimeoutSecs,
        payloadTimeoutSecs,
        headless,
        debug,
        proxyEnabled: Boolean(proxyInput?.useApifyProxy || proxyInput?.proxyUrls?.length),
    });
    await Actor.setStatusMessage('Starting Chromium and opening CryptoPanic');

    const proxy = await makePlaywrightProxy(proxyInput);
    const executablePath = process.env.PLAYWRIGHT_EXECUTABLE_PATH?.trim() || undefined;
    const launchOptions = {
        headless,
        slowMo: slowMoMillis || undefined,
        proxy,
        executablePath,
        args: [
            '--disable-gpu',
            '--disable-dev-shm-usage',
            '--disable-blink-features=AutomationControlled',
            '--no-sandbox',
        ],
    };

    let browser;
    try {
        log.info('Launching Chromium', {
            headless,
            proxyEnabled: Boolean(proxy),
            executablePath: executablePath ?? 'Playwright-managed browser',
        });
        browser = await chromium.launch(launchOptions);
    } catch (error) {
        throw new Error(
            'Chromium could not be started. Locally run `npx playwright install --with-deps chromium`. '
            + `Original error: ${error.message}`,
            { cause: error },
        );
    }

    try {
        const context = await browser.newContext({
            locale: 'en-US',
            viewport: { width: 1366, height: 900 },
            userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
                + '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        });
        const page = await context.newPage();

        const { rawPosts, stats, diagnostics } = await scrapeCryptoPanicFeed({
            page,
            feedUrl,
            maxItems,
            maxLoadMoreClicks,
            navigationTimeoutSecs,
            payloadTimeoutSecs,
            debug,
            logger: log,
            saveArtifacts,
        });

        const normalized = normalizeAndDeduplicate(rawPosts, { maxItems, maxAgeHours });
        let selected = normalized;
        let duplicateCount = 0;

        if (onlyNew) {
            const stateStore = await Actor.openKeyValueStore(stateStoreName);
            const stateKey = makeStateKey(feedUrl);
            const state = (await stateStore.getValue(stateKey)) ?? { ids: [] };
            const seen = new Set(Array.isArray(state.ids) ? state.ids : []);

            selected = normalized.filter(({ id }) => !seen.has(id));
            duplicateCount = normalized.length - selected.length;

            const nextIds = [...selected.map(({ id }) => id), ...seen].slice(0, 10_000);
            await stateStore.setValue(stateKey, {
                ids: nextIds,
                feedUrl,
                updatedAt: new Date().toISOString(),
            });
        }

        const outputItems = selected.map(({ item }) => item);
        const dataset = datasetName.trim()
            ? await Actor.openDataset(datasetName.trim())
            : await Actor.openDataset();

        if (outputItems.length > 0) await dataset.pushData(outputItems);

        const summary = {
            feedUrl,
            ...stats,
            uniqueRowsMatched: normalized.length,
            rowsStored: outputItems.length,
            previouslySeenSkipped: duplicateCount,
            finalUrl: diagnostics.url,
            pageTitle: diagnostics.title,
            datasetId: dataset.id,
            completedAt: new Date().toISOString(),
        };

        await Actor.setValue('OUTPUT', summary);
        await Actor.setStatusMessage(`Finished: ${outputItems.length} rows stored`, { isTerminal: true });
        log.info('CryptoPanic collection finished', summary);
    } finally {
        log.info('Closing Chromium');
        await browser.close();
    }
});
