import { expandDictList, normalizeAndDeduplicate } from './cryptopanic.js';

const NOOP_LOGGER = Object.freeze({
    debug() {},
    info() {},
    warning() {},
    error() {},
});

export async function installCaptureHook(page) {
    await page.addInitScript(() => {
        if (window.__CP_NEWS_HOOKED__) return;

        Object.defineProperty(window, '__CP_NEWS_PAYLOADS__', {
            value: [],
            writable: false,
            configurable: false,
        });
        window.__CP_NEWS_HOOKED__ = true;

        const originalParse = JSON.parse;
        JSON.parse = function patchedJsonParse(...args) {
            const parsed = originalParse.apply(this, args);
            try {
                const looksLikeNews =
                    parsed
                    && typeof parsed === 'object'
                    && Array.isArray(parsed.k)
                    && Array.isArray(parsed.l)
                    && parsed.k.includes('title')
                    && parsed.k.includes('published_at');

                if (looksLikeNews) window.__CP_NEWS_PAYLOADS__.push(parsed);
            } catch {
                // The hook must never interfere with CryptoPanic's page code.
            }
            return parsed;
        };
    });
}

export async function waitForNewPayload(page, timeoutMs) {
    try {
        await page.waitForFunction(
            () => (window.__CP_NEWS_PAYLOADS__?.length ?? 0) > 0,
            undefined,
            { timeout: timeoutMs },
        );
        return true;
    } catch {
        return false;
    }
}

export async function drainCapturedPayloads(page, rawPosts) {
    const payloads = await page.evaluate(() => {
        const queue = window.__CP_NEWS_PAYLOADS__ ?? [];
        return queue.splice(0, queue.length);
    });

    for (const payload of payloads) rawPosts.push(...expandDictList(payload));
    return payloads.length;
}

export async function clickLoadMoreOrScroll(page) {
    return page.evaluate(() => {
        const visible = (element) => {
            const style = window.getComputedStyle(element);
            const rect = element.getBoundingClientRect();
            return style.visibility !== 'hidden'
                && style.display !== 'none'
                && rect.width > 0
                && rect.height > 0;
        };

        const textPattern = /load\s*more|more\s*news|show\s*more|mehr\s*laden|weitere/i;
        const candidates = [...document.querySelectorAll('button, a, [role="button"]')];
        const textButton = candidates.find(
            (element) => visible(element) && textPattern.test(element.textContent ?? ''),
        );
        const classButton = [...document.querySelectorAll('.btn-outline-primary')].find(visible);
        const target = textButton ?? classButton;

        if (target) {
            target.scrollIntoView({ block: 'center', behavior: 'auto' });
            target.click();
            return 'clicked';
        }

        window.scrollTo({ top: document.body.scrollHeight, behavior: 'auto' });
        return 'scrolled';
    });
}

export async function collectPageDiagnostics(page, postsResponses = []) {
    const browserState = await page.evaluate(() => ({
        hookInstalled: Boolean(window.__CP_NEWS_HOOKED__),
        queuedPayloads: window.__CP_NEWS_PAYLOADS__?.length ?? 0,
        readyState: document.readyState,
        bodyText: (document.body?.innerText ?? '').slice(0, 2_000),
    })).catch((error) => ({ evaluationError: error.message }));

    return {
        url: page.url(),
        title: await page.title().catch(() => null),
        ...browserState,
        postsResponses,
        capturedAt: new Date().toISOString(),
    };
}

export async function scrapeCryptoPanicFeed({
    page,
    feedUrl,
    maxItems = 150,
    maxLoadMoreClicks = 12,
    navigationTimeoutSecs = 60,
    payloadTimeoutSecs = 30,
    debug = false,
    logger = NOOP_LOGGER,
    saveArtifacts = async () => {},
}) {
    const rawPosts = [];
    const postsResponses = [];
    let capturedPayloads = 0;
    let loadMoreAttempts = 0;

    page.on('response', (response) => {
        if (!response.url().includes('/web-api/posts/')) return;
        const record = { status: response.status(), url: response.url() };
        postsResponses.push(record);
        logger.info('CryptoPanic posts endpoint responded', record);
    });

    page.on('requestfailed', (request) => {
        if (request.isNavigationRequest() || request.url().includes('/web-api/posts/')) {
            logger.warning('Relevant browser request failed', {
                url: request.url(),
                resourceType: request.resourceType(),
                error: request.failure()?.errorText ?? 'unknown',
            });
        }
    });

    page.on('pageerror', (error) => {
        logger.warning('Browser page error', { error: error.message });
    });

    page.on('console', (message) => {
        if (debug || ['warning', 'error'].includes(message.type())) {
            logger.debug('Browser console message', {
                type: message.type(),
                text: message.text().slice(0, 1_000),
            });
        }
    });

    await page.route('**/*', async (route) => {
        const request = route.request();
        const resourceType = request.resourceType();
        const url = request.url();

        if (
            ['image', 'media', 'font'].includes(resourceType)
            || /google-analytics|googletagmanager|doubleclick|hotjar|clarity\.ms/i.test(url)
        ) {
            await route.abort();
            return;
        }
        await route.continue();
    });

    await installCaptureHook(page);
    logger.info('Capture hook installed; starting navigation', { feedUrl });

    const response = await page.goto(feedUrl, {
        waitUntil: 'domcontentloaded',
        timeout: navigationTimeoutSecs * 1_000,
    });

    logger.info('Navigation completed', {
        status: response?.status() ?? null,
        finalUrl: page.url(),
        title: await page.title().catch(() => null),
    });

    const initialPayload = await waitForNewPayload(page, payloadTimeoutSecs * 1_000);
    if (!initialPayload) {
        const diagnostics = await collectPageDiagnostics(page, postsResponses);
        await saveArtifacts('ERROR', page, diagnostics);
        throw new Error(
            `No structured CryptoPanic news payload was captured within ${payloadTimeoutSecs}s. `
            + `Final URL: ${diagnostics.url}; title: ${diagnostics.title ?? '(none)'}`,
        );
    }

    capturedPayloads += await drainCapturedPayloads(page, rawPosts);
    logger.info('Initial CryptoPanic payload captured', {
        payloadsCaptured: capturedPayloads,
        rawRowsCaptured: rawPosts.length,
    });

    let noProgressRounds = 0;
    while (loadMoreAttempts < maxLoadMoreClicks) {
        const currentCount = normalizeAndDeduplicate(rawPosts, {
            maxItems: Number.MAX_SAFE_INTEGER,
        }).length;
        if (currentCount >= maxItems) break;

        loadMoreAttempts += 1;
        const action = await clickLoadMoreOrScroll(page);
        logger.info('Requested additional news', {
            attempt: loadMoreAttempts,
            action,
            uniqueRowsSoFar: currentCount,
        });

        const received = await waitForNewPayload(page, 8_000);
        if (!received) {
            noProgressRounds += 1;
            logger.warning('No new payload after Load more/scroll', {
                attempt: loadMoreAttempts,
                action,
                noProgressRounds,
            });
            if (action === 'scrolled' || noProgressRounds >= 2) break;
            continue;
        }

        const before = rawPosts.length;
        capturedPayloads += await drainCapturedPayloads(page, rawPosts);
        noProgressRounds = rawPosts.length > before ? 0 : noProgressRounds + 1;

        logger.info('Additional CryptoPanic payload captured', {
            payloadsCaptured: capturedPayloads,
            rawRowsCaptured: rawPosts.length,
        });
        if (noProgressRounds >= 2) break;
    }

    const diagnostics = await collectPageDiagnostics(page, postsResponses);
    if (debug) await saveArtifacts('DEBUG', page, diagnostics);

    return {
        rawPosts,
        diagnostics,
        stats: {
            rawRowsCaptured: rawPosts.length,
            payloadsCaptured: capturedPayloads,
            loadMoreAttempts,
            postsResponses,
        },
    };
}
