import test from 'node:test';
import assert from 'node:assert/strict';

import {
    buildFeedUrl,
    expandDictList,
    normalizeAndDeduplicate,
    normalizePost,
} from '../src/cryptopanic.js';

test('buildFeedUrl maps the public feed filter', () => {
    assert.equal(buildFeedUrl({ filter: 'show-all' }), 'https://cryptopanic.com/news/?filter=all');
    assert.equal(buildFeedUrl({ filter: 'hot' }), 'https://cryptopanic.com/news/?filter=hot');
});

test('expandDictList expands CryptoPanic column-oriented data', () => {
    const rows = expandDictList({
        k: ['pk', 'title', 'published_at'],
        l: [[1, 'One', '2026-06-19T12:00:00Z'], [2, 'Two', '2026-06-19T11:00:00Z']],
    });
    assert.deepEqual(rows[0], { pk: 1, title: 'One', published_at: '2026-06-19T12:00:00Z' });
    assert.equal(rows.length, 2);
});

test('normalizePost emits the requested XLSX fields', () => {
    const item = normalizePost({
        pk: 123,
        title: 'Headline',
        body: 'Body',
        kind: 'link',
        published_at: '2026-06-19T12:00:00Z',
        created_at: '2026-06-19T12:01:00Z',
        url: 'https://example.com/article',
        domain: 'example.com',
        currencies_codes: ['btc', 'ETH'],
        ai_sentiment_level: 2,
        panic_score_1h: 4,
        content: { clean: 'Clean', original: '<p>Clean</p>' },
        source: { title: 'Example', domain: 'example.com', region: 'en' },
    });

    assert.deepEqual(item.coins, ['BTC', 'ETH']);
    assert.equal(item.headline, 'Headline');
    assert.equal(item.sourceUrl, 'https://example.com/article');
    assert.equal(item.contentClean, 'Clean');
    assert.equal(item.panicScore24h, null);
});

test('normalizeAndDeduplicate keeps newest unique rows', () => {
    const input = [
        { pk: 1, title: 'Older duplicate', published_at: '2026-06-19T10:00:00Z', url: 'https://a' },
        { pk: 1, title: 'Older duplicate', published_at: '2026-06-19T10:00:00Z', url: 'https://a' },
        { pk: 2, title: 'Newer', published_at: '2026-06-19T12:00:00Z', url: 'https://b' },
    ];
    const output = normalizeAndDeduplicate(input, { maxItems: 10 });
    assert.equal(output.length, 2);
    assert.equal(output[0].item.headline, 'Newer');
});
