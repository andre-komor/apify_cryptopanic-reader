import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import test from 'node:test';

import { chromium } from 'playwright';

import { normalizeAndDeduplicate } from '../src/cryptopanic.js';
import {
    clickLoadMoreOrScroll,
    drainCapturedPayloads,
    installCaptureHook,
    waitForNewPayload,
} from '../src/scrape.js';

function findChromium() {
    const candidates = [
        process.env.PLAYWRIGHT_EXECUTABLE_PATH,
        chromium.executablePath(),
        '/usr/bin/chromium',
        '/usr/bin/chromium-browser',
        '/usr/bin/google-chrome',
    ].filter(Boolean);
    return candidates.find((candidate) => existsSync(candidate));
}

const executablePath = findChromium();

test('browser hook captures initial and Load more payloads', { skip: !executablePath }, async () => {
    const first = {
        k: ['pk', 'title', 'published_at', 'currencies_codes', 'source'],
        l: [[1, 'First headline', '2026-06-20T12:00:00Z', ['BTC'], {
            title: 'Source A', domain: 'a.example', region: 'en',
        }]],
    };
    const second = {
        k: ['pk', 'title', 'published_at', 'currencies_codes', 'source'],
        l: [[2, 'Second headline', '2026-06-20T11:00:00Z', ['ETH'], {
            title: 'Source B', domain: 'b.example', region: 'en',
        }]],
    };

    const html = `<!doctype html>
        <html><body>
            <h1>Fixture feed</h1>
            <button id="more">Load more</button>
            <script>
                const first = ${JSON.stringify(first)};
                const second = ${JSON.stringify(second)};
                setTimeout(() => JSON.parse(JSON.stringify(first)), 100);
                document.querySelector('#more').addEventListener('click', () => {
                    JSON.parse(JSON.stringify(second));
                    document.querySelector('#more').remove();
                });
            </script>
        </body></html>`;

    const browser = await chromium.launch({
        headless: true,
        executablePath,
        args: ['--no-sandbox', '--disable-dev-shm-usage'],
    });

    try {
        const page = await browser.newPage();
        await installCaptureHook(page);
        await page.goto('about:blank');
        await page.setContent(html);

        const rawPosts = [];
        assert.equal(await waitForNewPayload(page, 5_000), true);
        assert.equal(await drainCapturedPayloads(page, rawPosts), 1);
        assert.equal(await clickLoadMoreOrScroll(page), 'clicked');
        assert.equal(await waitForNewPayload(page, 5_000), true);
        assert.equal(await drainCapturedPayloads(page, rawPosts), 1);

        assert.equal(rawPosts.length, 2);
        const normalized = normalizeAndDeduplicate(rawPosts, { maxItems: 2 });
        assert.deepEqual(normalized.map(({ item }) => item.headline), [
            'First headline',
            'Second headline',
        ]);
    } finally {
        await browser.close();
    }
});
