# AGENTS.md

## Scope
This repository contains a private Apify Actor that collects structured public CryptoPanic news.

## Required workflow
- Use Node.js 24 to match the Docker image.
- Do not use paid Apify cloud runs in automated tests.
- Run `npm run test:all` and `npm run check` after code changes.
- Use `INPUT.local.json` for local runs and fixtures for automated tests.
- Do not create or modify `.env` files.
- Keep the Actor private unless the user explicitly requests publication.

## Output contract
Preserve these dataset fields and their names:
`aiSentimentLevel`, `body`, `coins`, `contentClean`, `createdAt`, `headline`, `kind`, `panicScore`, `panicScore1h`, `panicScore24h`, `publishedAt`, `source`, `sourceRegion`, `sourceTitle`, `sourceUrl`.

`coins` must remain an array so Apify's XLSX export creates `coins/0`, `coins/1`, `coins/2`, and so on.

## Scraping constraints
- Start with the public feed and no login/session.
- Start without a proxy. Add an Apify datacenter proxy only after diagnostics show blocking.
- Do not invent missing sentiment or panic-score values; keep them as `null`.
- Preserve diagnostic logging and failure artifacts.
- Keep run frequency moderate and do not bypass access controls.

## Useful commands
- `npm ci`
- `npx playwright install --with-deps chromium`
- `npm run test:all`
- `APIFY_LOG_LEVEL=DEBUG apify run --input-file INPUT.local.json -p`
- `APIFY_LOG_LEVEL=DEBUG apify run --input-file INPUT.headful.json -p`
- `apify push --open`
